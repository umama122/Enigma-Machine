#include <stdbool.h>
#include <stdio.h>
#include <string.h>


char encrypt_forward(char, char *, int);
char encrypt_reverse(char, char *, int);
void rotate_offset_pos(int *);

// This code declares several arrays of characters which will be used in an encryption algorithm.
// The arrays represent the alphabet, plugboard, three rotors, and two reflectors used in a machine called the Enigma.

char alphabet[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
char plugboard[] = "ZPHNMSWCIYTQEDOBLRFKUVGXJA";
char rotor1[] = "EKMFLGDQVZNTOWYHXUSPAIBRCJ";
char rotor2[] = "AJDKSIRUXBLHWTMCQGZNPYFVOE";
char rotor3[] = "BDFHJLCPRTXVZNYEIWGAKMUSQO";
char reflector_B[] = "YRUHQSLDPXNGOKMIEBFZCWVJAT";
char reflector_C[] = "FVPJIAOYEDRZXWGCTKUQSBNMHL";

char turnover_pos1 = 'Q';
char turnover_pos2 = 'E';
char turnover_pos3 = 'V';


// The code also declares three integer variables to represent the current offset positions of the three rotors.
int offset_pos1 = 0;
int offset_pos2 = 0;
int offset_pos3 = 0;


// the code defines a function that determines whether a rotor should be rotated based on its current offset position and a turnover position
bool enable_rotate(int current_offset_pos, char turnover_pos) {
  int turnover_pos_index = turnover_pos - 'A';
  int next_index = (current_offset_pos + 1) % 25;
  return next_index == turnover_pos_index;
}

int main() {
  int choice; //stores the choice the user chooses
  printf("Enter 1 to enter a string or 2 to enter a filename: ");
  scanf("%d", &choice);

  // Take user input for the offset positions and stores them accordinly to which offset is chosen
  if (choice == 2) {
    char input_file_name[100];
    printf("\nPlease enter the desired offset_pos for rotor 1 (0-25): ");
    scanf("%d", &offset_pos1);

    printf("\nPlease enter the desired offset_pos for rotor 2 (0-25): ");
    scanf("%d", &offset_pos2);

    printf("\nPlease enter the desired offset_pos for rotor 3 (0-25): ");
    scanf("%d", &offset_pos3);
    
//stores the reflector choice 
    printf("\nPlease enter the reflector you want to use (B or C): ");
    char reflector_choice;
    scanf(" %c", &reflector_choice);
    char *reflector = (reflector_choice == 'B') ? reflector_B : reflector_C;

    //asks the user for the input file name containing 
    printf("\nPlease enter the input text file name: ");
    scanf("%s", input_file_name);

    char output_file_name[100];
    printf("\nPlease enter the output text file name: ");
    scanf("%s", output_file_name);
//readsfile
    FILE *input_file = fopen(input_file_name, "r");
  //writes to outputfile
    FILE *output_file = fopen(output_file_name, "w");

    if (input_file == NULL) {
      printf("\nError: Unable to open input file.\n");
      return 1;
    }

    if (output_file == NULL) {
      printf("\nError: Unable to open output file.\n");
      return 1;
    }
//takes the strings from the file
    char input_str[10000];
    fgets(input_str, 10000, input_file);
    
//stores the length of the string
    int len = strlen(input_str);
//A new character array encrypted_str is then created to store the encrypted string
    char encrypted_str[len + 1];
//for loops itertates through each character
    for (int i = 0; i < len; i++) {
      char input_char = input_str[i];


      //checks for whitespace
if (input_char != ' ') {
      input_char = encrypt_forward(input_char, plugboard, 0);
  //checks if the rotors have reached their offset position 
      if (enable_rotate(offset_pos1, turnover_pos1)) {
        rotate_offset_pos(&offset_pos2);
        if (enable_rotate(offset_pos2, turnover_pos2)) {
          rotate_offset_pos(&offset_pos3);
        }
      }
      rotate_offset_pos(&offset_pos1);
//characters are passed through the encrypt forward function
      input_char = encrypt_forward(input_char, rotor1, offset_pos1);
      input_char = encrypt_forward(input_char, rotor2, offset_pos2);
      input_char = encrypt_forward(input_char, rotor3, offset_pos3);
  //character passed through the reflector
      input_char = encrypt_forward(input_char, reflector, 0);
//reverse path , characters are passed through the reverse fucntion
      input_char = encrypt_reverse(input_char, rotor3, offset_pos3);
      input_char = encrypt_reverse(input_char, rotor2, offset_pos2);
      input_char = encrypt_reverse(input_char, rotor1, offset_pos1);
      input_char = encrypt_reverse(input_char, plugboard, 0);
}
      // the resulting encrypted character is then stored in the encrypted_str array. this process is repeated for each character in the input string.
      encrypted_str[i] = input_char;
    }

    encrypted_str[len] = '\0';
    fputs(encrypted_str, output_file);
    //encrypted string is stored to the output file

    printf("\n\n Encrypted text has been written to the output file.\n");

    fclose(input_file);
    fclose(output_file);
    //closes both files

    return 0;


    // SAME PROCESS REPEATED FOR THE STRING !!
  } else if (choice == 1) {
    char input_str[100];
    //ofset positions are selected
    printf("\nPlease enter the desired offset_pos for rotor 1 (0-25): ");
    scanf("%d", &offset_pos1);

    printf("\nPlease enter the desired offset_pos for rotor 2 (0-25): ");
    scanf("%d", &offset_pos2);

    printf("\nPlease enter the desired offset_pos for rotor 3 (0-25): ");
    scanf("%d", &offset_pos3);
//reflector is selected
    printf("\nPlease enter the reflector you want to use (B or C): ");
    char reflector_choice;
    scanf(" %c", &reflector_choice);
    char *reflector = (reflector_choice == 'B') ? reflector_B : reflector_C;
//stored the string as input_str
    printf("\n Please enter a string to encrypt:");
    scanf("%s", input_str);
//stores the length of the str 
    int len = strlen(input_str);
    char encrypted_str[len + 1];

    for (int i = 0; i < len; i++) {
      char input_char = input_str[i];

      input_char = encrypt_forward(input_char, plugboard, 0);
      if (enable_rotate(offset_pos1, turnover_pos1)) {
        rotate_offset_pos(&offset_pos2);
        if (enable_rotate(offset_pos2, turnover_pos2)) {
          rotate_offset_pos(&offset_pos3);
        }
      }
      rotate_offset_pos(&offset_pos1);
//encrypts each character through the forward path
      input_char = encrypt_forward(input_char, rotor1, offset_pos1);
      input_char = encrypt_forward(input_char, rotor2, offset_pos2);
      input_char = encrypt_forward(input_char, rotor3, offset_pos3);
      input_char = encrypt_forward(input_char, reflector, 0);
//encrypts each character through the reverse path
      input_char = encrypt_reverse(input_char, rotor3, offset_pos3);
      input_char = encrypt_reverse(input_char, rotor2, offset_pos2);
      input_char = encrypt_reverse(input_char, rotor1, offset_pos1);
      input_char = encrypt_reverse(input_char, plugboard, 0);

      encrypted_str[i] = input_char;
    }

    encrypted_str[len] = '\0';

    printf("\n\n Encrypted string is = %s \n", encrypted_str);

    return 0;
  }
}
char encrypt_reverse(char letter, char *encrypt_table, int offset_pos) {
  int initial_index = (letter - 'A' + offset_pos) % 26;
  
 // Loop through all possible characters and check which one
  // matches the input letter when using the forward encryption process
  for (int i = 0; i < 26; i++) {
    char candidate = 'A' + i;
    if (encrypt_forward(candidate, encrypt_table, offset_pos) == letter) {
      return candidate;
    }
  }

  return 0; // This line is added to prevent a compiler warning for a missing
            // return statement.
}

char encrypt_forward(char letter, char *encrypt_table, int offset_pos) {
  int initial_index = (letter - 'A' + offset_pos) % 26;
  char encrypted_letter = encrypt_table[initial_index];
  int adjusted_index = (encrypted_letter - 'A' - offset_pos + 26) % 26;

  return 'A' + adjusted_index;
}

void rotate_offset_pos(int *offset_pos) {
  if (*offset_pos == 25) {
    *offset_pos = 0;
  } else {
    (*offset_pos)++;
  }
}